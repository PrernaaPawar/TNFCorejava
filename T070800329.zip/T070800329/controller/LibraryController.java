package com.springCRUDfinal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springCRUDfinal.entity.Library;
import com.springCRUDfinal.service.libService;

@RestController
public class LibraryController {

	@Autowired
	public libService service;
	
	@PostMapping("/addstudent")
	public Library regEmployee(@RequestBody Library stud)
	{
		return service.addStudent(stud);
	}
	
	@GetMapping("/getstudent")
	public List <Library> getStudent() {
		return service.getStudent();
	}
	
	@DeleteMapping("/deletestudent/{id}")
	public void deletestudent(@PathVariable Integer id) {
		service.deletestudent(id);
	}
	
	@PutMapping("/updatestudent")
	
		public Library updatestudent(@RequestBody Library stud)
		{
			return service.updatestudent(stud);
		}
	
	
}
