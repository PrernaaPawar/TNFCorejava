package com.springCRUDfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcurdexampleApplication {

	public static void main(String args[])
	{
		SpringApplication.run(SpringcurdexampleApplication.class, args);
	}
}
