package com.springCRUDfinal.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Library {
    @Id
   
    //to give instruction to JPA that empid is the primary key-->@Id annotation
	private int libid;
    private String studname;
	private long cardno;
	private String bookname;
    public int getLibid() {
		return libid;
	}
	public void setLibid(int libid) {
		this.libid = libid;
	}
	public String getStudname() {
		return studname;
	}
	public void setStudname(String studname) {
		this.studname = studname;
	}
	public long getCardno() {
		return cardno;
	}
	public void setCardno(long cardno) {
		this.cardno = cardno;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	@Override
	public String toString() {
		return "Library [libid=" + libid + ", studname=" + studname + ", cardno=" + cardno + ", bookname=" + bookname
				+ "]";
	}
	
	
	
		
}
