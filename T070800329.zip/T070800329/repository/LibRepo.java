package com.springCRUDfinal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springCRUDfinal.entity.Library;

//converting database to table the jpaRepository is used.
public interface LibRepo extends JpaRepository<Library,Integer>{
	
	
}


