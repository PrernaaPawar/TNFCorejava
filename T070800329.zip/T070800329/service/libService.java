package com.springCRUDfinal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springCRUDfinal.entity.Library;
import com.springCRUDfinal.repository.LibRepo;

@Service
public class libService {
	@Autowired
	private LibRepo librepo;
	
	//adding employee details
	public Library addStudent(Library stud)
	{
		return librepo.save(stud);
	}
	
	
//	//read the employee details 
//	public List<Library> getStudent() {
//		return librepo.findAll();
//	}


	public List<Library> getStudent() {
		// TODO Auto-generated method stub
		return librepo.findAll();
	}


	public void deletestudent(Integer id) {
		// TODO Auto-generated method stub
		librepo.deleteById(id);
		
	}


	public Library updatestudent(Library stud) {
		// TODO Auto-generated method stub
		Integer id=stud.getLibid();
		Library lib1=librepo.findById(id).get();
		lib1.setBookname(stud.getBookname());
		lib1.setCardno(lib1.getCardno());
		return librepo.save(lib1);
	}
    
}
